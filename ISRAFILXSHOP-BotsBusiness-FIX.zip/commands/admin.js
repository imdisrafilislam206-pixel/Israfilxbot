/*CMD
  command: /admin
  help: Admin panel information
  answer: Admin panel
CMD*/
Bot.sendMessage("👑 ADMIN\n\nAdmin ID configured in project notes: 8312390543\n\nনিরাপত্তার জন্য এই প্রাথমিক সংস্করণে কোনো Admin action বা balance/payment approval command সক্রিয় করা হয়নি। আগে bot import ও test করুন, তারপর secure admin controls যোগ করতে হবে।");
