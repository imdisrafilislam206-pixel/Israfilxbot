/*CMD
  command: /help
  help: Help and command list
  answer: Help
CMD*/
Bot.sendMessage("📚 COMMANDS\n/start — Start\n/menu — Menu\n/packages — Packages\n/buy — Order request\n/deposit — Payment instructions\n/wallet — Wallet info\n/myorders — Order info\n/support — Support\n/admin — Admin info");
