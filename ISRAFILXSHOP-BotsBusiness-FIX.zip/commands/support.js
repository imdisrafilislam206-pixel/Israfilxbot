/*CMD
  command: /support
  help: Contact customer support
  answer: Customer support
CMD*/
Bot.sendMessage("🎧 CUSTOMER SUPPORT\n\nআপনার Telegram username, Player ID, প্যাকেজ এবং সমস্যার বিবরণ লিখে Admin-কে পাঠান।\n\nAdmin ID: 8312390543\n\nSupport username এখানে বসাতে হবে।");
