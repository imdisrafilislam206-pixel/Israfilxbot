/*CMD
  command: /deposit
  help: Manual payment instructions
  answer: Deposit instructions
CMD*/
Bot.sendMessage("💳 MANUAL DEPOSIT\n\nbKash/Nagad নম্বর Admin এখানে বসাবেন।\n\nপেমেন্ট করার আগে Admin-এর কাছ থেকে সঠিক নম্বর ও পরিমাণ নিশ্চিত করুন। পেমেন্টের পর Transaction ID এবং স্ক্রিনশট Support-এ পাঠান: /support\n\n⚠️ এই প্রাথমিক সংস্করণে স্বয়ংক্রিয় পেমেন্ট যাচাই চালু নেই।");
