/*CMD
  command: /wallet
  help: Wallet information
  answer: Wallet
CMD*/
Bot.sendMessage("💰 WALLET\n\nএই প্রাথমিক Git-import সংস্করণে স্বয়ংক্রিয় Wallet balance সংরক্ষণ/লেনদেন চালু নেই। আপনার পেমেন্ট ও ব্যালেন্স Admin-এর সঙ্গে যাচাই করুন: /support");
