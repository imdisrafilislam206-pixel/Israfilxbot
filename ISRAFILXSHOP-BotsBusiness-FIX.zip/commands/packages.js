/*CMD
  command: /packages
  help: View Free Fire Like packages
  answer: Free Fire Like Packages
CMD*/
Bot.sendMessage("❤️ FREE FIRE LIKE PACKAGES\n\nএখানে আপনার নির্ধারিত প্যাকেজ ও মূল্য Admin-কে দিয়ে আপডেট করাতে হবে।\n\nউদাহরণ:\n200 Likes — 1 Day — ৳25\n\nঅর্ডার করতে /buy লিখুন এবং প্যাকেজের নাম পাঠান। পেমেন্টের আগে Admin-এর কাছ থেকে মূল্য নিশ্চিত করুন।");
