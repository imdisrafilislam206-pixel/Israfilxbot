/*CMD
  command: /start
  help: Open ISRAFILXSHOP menu
  answer: Welcome to ISRAFILXSHOP
  keyboard: 🛒 Packages, 💳 Deposit
  keyboard: 💰 Wallet, 📦 My Orders
  keyboard: 🎧 Support, 🌐 English
CMD*/
Bot.sendMessage("❤️ স্বাগতম ISRAFILXSHOP-এ!\n\nFree Fire Like সার্ভিস, প্যাকেজ ও অর্ডারের তথ্য পেতে /menu লিখুন।\n\nWelcome to ISRAFILXSHOP! Use /menu to view services.");
