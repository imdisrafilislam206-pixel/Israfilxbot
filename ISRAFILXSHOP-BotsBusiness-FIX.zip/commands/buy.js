/*CMD
  command: /buy
  help: Request a new order
  answer: Order request
  need_reply: true
CMD*/
Bot.sendMessage("🛒 অর্ডার করতে আপনার প্যাকেজের নাম, Free Fire Player ID এবং Server লিখে এক মেসেজে পাঠান।\n\nAdmin আপনার অর্ডার ও মূল্য যাচাই করে রিপ্লাই করবেন। এখনই টাকা পাঠাবেন না।");
