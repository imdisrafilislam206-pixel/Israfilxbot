/*CMD
  command: /myorders
  help: Order history information
  answer: My orders
CMD*/
Bot.sendMessage("📦 MY ORDERS\n\nএই প্রাথমিক সংস্করণে অর্ডার হিস্টোরি স্বয়ংক্রিয়ভাবে সংরক্ষিত হয় না। আপনার অর্ডারের অবস্থা জানতে Support-এ যোগাযোগ করুন: /support");
