/*CMD
  command: /menu
  help: Show shop menu
  answer: ISRAFILXSHOP Menu
  keyboard: 🛒 Packages, 💳 Deposit
  keyboard: 💰 Wallet, 📦 My Orders
  keyboard: 🎧 Support
CMD*/
Bot.sendMessage("🛍️ ISRAFILXSHOP MENU\n\n🛒 প্যাকেজ দেখতে /packages\n💳 পেমেন্ট নির্দেশনা /deposit\n💰 Wallet তথ্য /wallet\n📦 অর্ডার তথ্য /myorders\n🎧 Support /support\n\nPrices and availability must be confirmed by admin before payment.");
