# ISRAFILXSHOP — Bots.Business Git Import

This repository uses the Bots.Business Git sync layout:
- `bot.json` at repository root
- `commands/` for BJS command files
- `libs/` for optional shared libraries

## Import
1. Upload the contents of this folder to the ROOT of your existing GitHub repository (not inside another nested folder).
2. Keep the repository private if you prefer.
3. In Bots.Business > Tools > Git Sync, configure the repository and add the app's public deploy key to GitHub.
4. Import from Git.

## Important
This is a safe starter/import structure. It provides basic command replies and menu navigation.
It does NOT yet implement persistent wallet accounting, automatic bKash/Nagad gateway verification,
automatic Free Fire delivery, or secure admin approval workflows. Those require verified provider APIs
and additional BJS implementation/testing. Do not accept real payments based only on this starter.

Before importing, make a copy/backup of your bot because Git import can replace existing commands.
