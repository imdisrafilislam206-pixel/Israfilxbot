# ISRAFILXSHOP — Bots.Business BJS

এটি Bots.Business Git import-এর জন্য BJS JavaScript starter project।

## Import করার আগে
- `commands/_deposit.js`-এ bKash/Nagad নম্বর বসান।
- `commands/_support.js`-এ support username বসান।
- সব কমান্ডে `8312390543` আপনার Telegram numeric admin ID দিয়ে বদলান (না বদলালে এই ID-ই admin থাকবে)।
- প্যাকেজের মূল্য ও মেয়াদ যাচাই করুন।

## GitHub → Bots.Business
1. ZIP extract করে সব ফাইল নতুন GitHub repository-র root-এ upload করুন।
2. `bot.json` root-এ আছে নিশ্চিত করুন এবং default branch `main` রাখুন।
3. Bots.Business-এ আগে একটি test bot খুলুন।
4. Tools → Git Sync → Configure Git → repository URL দিন।
5. App-এর Copy key দিয়ে পাওয়া public SSH key GitHub repository-র Deploy keys-এ যোগ করুন।
6. Tools → Git Sync → Import from Git চাপুন।
7. `/start`, `/buy`, `/deposit`, `/wallet` এবং admin commands পরীক্ষা করুন।

## Commands
/start, /help, /buy, /like200, /like520, /like1000, /like2000, /wallet, /deposit, /submitproof, /orders, /support, /admin, /pending, /approve, /reject, /complete, /refund, /setbalance, /stats, /broadcast

## গুরুত্বপূর্ণ
- Git import destination bot-এর commands ও installed libraries replace করে। আগে backup/test bot ব্যবহার করুন।
- Automatic bKash/Nagad gateway যুক্ত নেই; এখানে manual transaction ID review আছে। Automatic payment-এর জন্য অনুমোদিত merchant gateway এবং server-side verification integrate করতে হবে।
- Free Fire Like delivery manual admin fulfilment; game API integration নেই।
- এটি starter template; real-money launch-এর আগে test, security review, payment verification ও data handling পরীক্ষা করুন।
- Telegram token, gateway secret, PIN, OTP বা private key GitHub-এ রাখবেন না।
