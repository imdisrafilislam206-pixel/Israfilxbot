/*CMD
  command: /wallet
  help: Check wallet balance
  need_reply: false
CMD*/
var balance = Number(Bot.getProperty("isx_user_balance_" + String(user.telegramid)) || 0);
Bot.sendMessage("💰 *YOUR WALLET*\nBalance: ৳" + balance + "\nUse /deposit to add balance.");
