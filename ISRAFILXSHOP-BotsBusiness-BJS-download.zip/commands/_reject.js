/*CMD
  command: /reject
  help: Reject deposit
  need_reply: false
CMD*/
if (String(user.telegramid)!=="8312390543") { Bot.sendMessage("⛔ Access denied."); return; }
var id=(message||"").trim().split(/\s+/)[1];
if(!id){Bot.sendMessage("Usage: /reject DEPOSIT_ID");return;}
var ds=Bot.getProperty("isx_deposits")||[], d=ds.find(function(x){return x.id===id;});
if(!d||d.status!=="PENDING"){Bot.sendMessage("Request not found or already processed.");return;}
d.status="REJECTED"; Bot.setProperty("isx_deposits",ds,"json");
Bot.sendMessageToChatWithId(d.user_id,"❌ Deposit request "+id+" was rejected. Contact support if needed.");
Bot.sendMessage("Rejected "+id);
