/*CMD
  command: /refund
  help: Refund an order
  need_reply: false
CMD*/
if (String(user.telegramid)!=="8312390543") { Bot.sendMessage("⛔ Access denied."); return; }
var id=(message||"").trim().split(/\s+/)[1];
if(!id){Bot.sendMessage("Usage: /refund ORDER_ID");return;}
var os=Bot.getProperty("isx_orders")||[], o=os.find(function(x){return x.id===id;});
if(!o||o.status!=="PENDING"){Bot.sendMessage("Order not found or already processed.");return;}
o.status="REFUNDED"; Bot.setProperty("isx_orders",os,"json");
var key="isx_user_balance_"+o.user_id, bal=Number(Bot.getProperty(key)||0)+Number(o.price);
Bot.setProperty(key,bal,"number");
Bot.sendMessageToChatWithId(o.user_id,"↩️ Order "+id+" cancelled. ৳"+o.price+" refunded. New balance: ৳"+bal);
Bot.sendMessage("Refunded "+id);
