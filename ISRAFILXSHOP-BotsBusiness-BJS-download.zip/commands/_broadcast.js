/*CMD
  command: /broadcast
  help: Broadcast to private chats
  need_reply: false
CMD*/
if (String(user.telegramid)!=="8312390543") { Bot.sendMessage("⛔ Access denied."); return; }
var msg=(message||"").replace(/^\/broadcast\s*/,"").trim();
if(!msg){Bot.sendMessage("Usage: /broadcast Your announcement");return;}
Bot.sendMessageToAllPrivateChats("📢 *ISRAFILXSHOP ANNOUNCEMENT*\n\n"+msg);
Bot.sendMessage("Broadcast submitted.");
