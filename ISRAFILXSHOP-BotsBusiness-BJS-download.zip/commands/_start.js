/*CMD
  command: /start
  help: Start ISRAFILXSHOP
  need_reply: false
CMD*/
var name = user.first_name || "Customer";
Bot.sendMessage("🔥 *WELCOME TO ISRAFILXSHOP* 🔥\nHello " + name + "!\nFree Fire Like Service Shop\n\n/buy - Buy Like packages\n/wallet - Check wallet\n/deposit - Add balance\n/orders - My orders\n/support - Customer support\n/help - Help");
Bot.sendKeyboard("/buy, /wallet\n/deposit, /orders\n/support, /help", "👇 Select an option");
