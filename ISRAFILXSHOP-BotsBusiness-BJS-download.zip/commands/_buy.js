/*CMD
  command: /buy
  help: View Like packages
  need_reply: false
CMD*/
Bot.sendMessage("❤️ *FREE FIRE LIKE PACKAGES*\n\n200 Likes — 1 Day — ৳25: /like200\n520 Likes — 7 Days — ৳60: /like520\n1,000 Likes — 15 Days — ৳100: /like1000\n2,000 Likes — 30 Days — ৳180: /like2000\n\nAdmin can edit prices in the package command files.");
