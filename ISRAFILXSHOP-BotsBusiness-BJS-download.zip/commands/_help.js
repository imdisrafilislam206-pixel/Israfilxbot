/*CMD
  command: /help
  help: Help and commands
  need_reply: false
CMD*/
Bot.sendMessage("📚 *HELP*\n/buy - View packages\n/wallet - Check balance\n/deposit - Deposit instructions\n/submitproof AMOUNT TRXID - Submit payment\n/orders - Order history\n/support - Contact support\n/admin - Admin panel");
