/*CMD
  command: /like2000
  help: Order 2,000 Likes — 30 Days
  need_reply: false
CMD*/
var uid = String(user.telegramid);
var key = "isx_user_balance_" + uid;
var balance = Number(Bot.getProperty(key) || 0);
var price = 180;
if (balance < price) {
  Bot.sendMessage("❌ Insufficient balance.\nPackage: 2,000 Likes — 30 Days\nPrice: ৳" + price + "\nBalance: ৳" + balance + "\nUse /deposit to add balance.");
  return;
}
var orderId = "ISX" + String(Date.now()).slice(-8);
var orders = Bot.getProperty("isx_orders") || [];
orders.push({id:orderId,user_id:uid,username:user.username||"",product:"2,000 Likes — 30 Days",price:price,status:"PENDING",created_at:new Date().toISOString()});
Bot.setProperty("isx_orders", orders, "json");
Bot.setProperty(key, balance-price, "number");
Bot.sendMessage("✅ *ORDER PLACED*\nID: " + orderId + "\nPackage: 2,000 Likes — 30 Days\nPaid: ৳" + price + "\nStatus: PENDING\nUse /orders to check.");
Bot.sendMessageToChatWithId("8312390543", "🛒 NEW ORDER\nID: "+orderId+"\nUser: "+uid+"\nPackage: 2,000 Likes — 30 Days\nPrice: ৳"+price+"\nComplete: /complete "+orderId+"\nRefund: /refund "+orderId);
