/*CMD
  command: /setbalance
  help: Set user balance
  need_reply: false
CMD*/
if (String(user.telegramid)!=="8312390543") { Bot.sendMessage("⛔ Access denied."); return; }
var p=(message||"").trim().split(/\s+/), uid=p[1], amount=Number(p[2]);
if(!uid||!isFinite(amount)||amount<0){Bot.sendMessage("Usage: /setbalance USER_ID AMOUNT");return;}
Bot.setProperty("isx_user_balance_"+uid,amount,"number");
Bot.sendMessageToChatWithId(uid,"Your wallet balance is now ৳"+amount);
Bot.sendMessage("Updated balance for "+uid+" to ৳"+amount);
