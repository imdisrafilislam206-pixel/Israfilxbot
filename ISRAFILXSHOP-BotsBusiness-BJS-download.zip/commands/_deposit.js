/*CMD
  command: /deposit
  help: Add money to wallet
  need_reply: false
CMD*/
Bot.sendMessage("💳 *MANUAL PAYMENT*\n\nbKash: ADD_YOUR_BKASH_NUMBER\nNagad: ADD_YOUR_NAGAD_NUMBER\n\nAfter sending money, submit:\n/submitproof AMOUNT TRXID\nExample: /submitproof 100 ABC123XYZ\n\nNever share PIN or OTP.");
