/*CMD
  command: /orders
  help: View your orders
  need_reply: false
CMD*/
var orders = Bot.getProperty("isx_orders") || [];
var mine = orders.filter(function(o){return String(o.user_id)===String(user.telegramid);});
if (!mine.length) { Bot.sendMessage("No orders yet. Use /buy."); return; }
var out = "📦 *YOUR ORDERS*\n\n";
mine.slice(-15).reverse().forEach(function(o){out += o.id+" | "+o.product+" | ৳"+o.price+" | "+o.status+"\n\n";});
Bot.sendMessage(out);
