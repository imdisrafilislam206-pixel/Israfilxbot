/*CMD
  command: /pending
  help: Show pending requests
  need_reply: false
CMD*/
if (String(user.telegramid)!=="8312390543") { Bot.sendMessage("⛔ Access denied."); return; }
var ds=Bot.getProperty("isx_deposits")||[], os=Bot.getProperty("isx_orders")||[];
var out="⏳ *PENDING DEPOSITS*\n";
var pd=ds.filter(function(x){return x.status==="PENDING";});
var po=os.filter(function(x){return x.status==="PENDING";});
if(!pd.length) out+="None\n";
pd.forEach(function(x){out+=x.id+" | "+x.user_id+" | ৳"+x.amount+" | "+x.trx+"\n";});
out+="\n🛒 *PENDING ORDERS*\n";
if(!po.length) out+="None\n";
po.forEach(function(x){out+=x.id+" | "+x.user_id+" | "+x.product+"\n";});
Bot.sendMessage(out);
