/*CMD
  command: /submitproof
  help: Submit payment proof
  need_reply: false
CMD*/
var parts = (message || "").trim().split(/\s+/);
if (parts.length < 3) { Bot.sendMessage("Format: /submitproof AMOUNT TRXID\nExample: /submitproof 100 ABC123XYZ"); return; }
var amount = Number(parts[1]), trx = parts[2];
if (!isFinite(amount) || amount <= 0 || amount > 50000 || trx.length < 5) { Bot.sendMessage("Invalid amount or transaction ID."); return; }
var deposits = Bot.getProperty("isx_deposits") || [];
if (deposits.some(function(d){return d.trx.toLowerCase()===trx.toLowerCase();})) { Bot.sendMessage("This transaction ID was already submitted."); return; }
var id = "DEP" + String(Date.now()).slice(-8);
deposits.push({id:id,user_id:String(user.telegramid),amount:amount,trx:trx,status:"PENDING",created_at:new Date().toISOString()});
Bot.setProperty("isx_deposits",deposits,"json");
Bot.sendMessage("✅ Deposit request submitted.\nRequest ID: "+id+"\nAmount: ৳"+amount+"\nStatus: PENDING");
Bot.sendMessageToChatWithId("8312390543","💳 DEPOSIT REQUEST\nID: "+id+"\nUser: "+user.telegramid+"\nAmount: ৳"+amount+"\nTRX: "+trx+"\nApprove: /approve "+id+"\nReject: /reject "+id);
