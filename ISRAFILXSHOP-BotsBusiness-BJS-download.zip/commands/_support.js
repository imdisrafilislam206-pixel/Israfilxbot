/*CMD
  command: /support
  help: Customer support
  need_reply: false
CMD*/
Bot.sendMessage("🎧 *CUSTOMER SUPPORT*\nContact: @YOUR_SUPPORT_USERNAME\nPlease include your order or deposit request ID.");
