/*CMD
  command: /stats
  help: Shop statistics
  need_reply: false
CMD*/
if (String(user.telegramid)!=="8312390543") { Bot.sendMessage("⛔ Access denied."); return; }
var os=Bot.getProperty("isx_orders")||[], ds=Bot.getProperty("isx_deposits")||[];
Bot.sendMessage("📊 *SHOP STATS*\nOrders: "+os.length+"\nPending orders: "+os.filter(function(x){return x.status==="PENDING";}).length+"\nCompleted: "+os.filter(function(x){return x.status==="COMPLETED";}).length+"\nDeposits: "+ds.length+"\nPending deposits: "+ds.filter(function(x){return x.status==="PENDING";}).length);
