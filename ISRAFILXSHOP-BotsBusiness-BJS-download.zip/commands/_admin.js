/*CMD
  command: /admin
  help: Admin panel
  need_reply: false
CMD*/
if (String(user.telegramid)!=="8312390543") { Bot.sendMessage("⛔ Access denied."); return; }
Bot.sendMessage("👑 *ADMIN PANEL*\n/pending\n/approve DEPOSIT_ID\n/reject DEPOSIT_ID\n/complete ORDER_ID\n/refund ORDER_ID\n/setbalance USER_ID AMOUNT\n/stats\n/broadcast MESSAGE");
