/*CMD
  command: /complete
  help: Complete an order
  need_reply: false
CMD*/
if (String(user.telegramid)!=="8312390543") { Bot.sendMessage("⛔ Access denied."); return; }
var id=(message||"").trim().split(/\s+/)[1];
if(!id){Bot.sendMessage("Usage: /complete ORDER_ID");return;}
var os=Bot.getProperty("isx_orders")||[], o=os.find(function(x){return x.id===id;});
if(!o||o.status!=="PENDING"){Bot.sendMessage("Order not found or already processed.");return;}
o.status="COMPLETED"; Bot.setProperty("isx_orders",os,"json");
Bot.sendMessageToChatWithId(o.user_id,"🎉 Your order "+id+" is completed. Thank you!");
Bot.sendMessage("Completed "+id);
