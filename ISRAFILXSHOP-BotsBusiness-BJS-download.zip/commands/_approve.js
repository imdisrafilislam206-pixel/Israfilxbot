/*CMD
  command: /approve
  help: Approve deposit
  need_reply: false
CMD*/
if (String(user.telegramid)!=="8312390543") { Bot.sendMessage("⛔ Access denied."); return; }
var id=(message||"").trim().split(/\s+/)[1];
if(!id){Bot.sendMessage("Usage: /approve DEPOSIT_ID");return;}
var ds=Bot.getProperty("isx_deposits")||[], d=ds.find(function(x){return x.id===id;});
if(!d||d.status!=="PENDING"){Bot.sendMessage("Request not found or already processed.");return;}
d.status="APPROVED"; Bot.setProperty("isx_deposits",ds,"json");
var key="isx_user_balance_"+d.user_id, bal=Number(Bot.getProperty(key)||0)+Number(d.amount);
Bot.setProperty(key,bal,"number");
Bot.sendMessageToChatWithId(d.user_id,"✅ Deposit approved: ৳"+d.amount+"\nNew wallet balance: ৳"+bal);
Bot.sendMessage("Approved "+id+". New balance: ৳"+bal);
