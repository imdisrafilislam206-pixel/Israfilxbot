from database import add_ledger, user_balance

def credit_wallet(user_id: int, amount: float, reference: str, note: str):
    if amount <= 0:
        raise ValueError("Amount must be positive")
    add_ledger(user_id, amount, "CREDIT", reference, note)
    return user_balance(user_id)
