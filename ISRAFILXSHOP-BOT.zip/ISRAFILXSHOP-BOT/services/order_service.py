from database import create_order

def place_order(user_id, product, game_uid="", server=""):
    return create_order(user_id, product, game_uid, server)
