"""
Payment gateway integration boundary.

Do not mark a payment as paid based only on a browser redirect or a screenshot.
A real provider adapter must verify the provider's signed server-to-server webhook,
amount, currency, transaction ID, and merchant account before approving a deposit.

This project intentionally ships with gateway mode disabled. Add the official API
credentials and webhook verification for your chosen licensed provider first.
"""
class GatewayNotConfigured(Exception):
    pass

def create_payment(amount_bdt: float, deposit_id: int, customer_id: int):
    raise GatewayNotConfigured(
        "No payment provider is configured. Use manual bKash/Nagad approval until "
        "an official gateway adapter is installed."
    )

def verify_webhook(headers, raw_body):
    raise GatewayNotConfigured("Webhook signature verification is not configured.")
