import logging
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters
from config import BOT_TOKEN
from database import init_db
from handlers.start import start, menu_callback, text_router
from handlers.wallet import balance, deposit, payment_proof
from handlers.orders import my_orders
from handlers.support import support
from handlers.admin import (
    admin, users, stats, add_product, products, set_price, approve_deposit,
    reject_deposit, complete_order, reject_order, credit, debit, broadcast,
    group_post, set_group, set_payment_info, command_logs
)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is missing. Add it to your environment variables.")
    init_db()
    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("menu", start))
    app.add_handler(CommandHandler("balance", balance))
    app.add_handler(CommandHandler("deposit", deposit))
    app.add_handler(CommandHandler("myorders", my_orders))
    app.add_handler(CommandHandler("support", support))

    # Admin-only commands (authorization is checked inside each handler)
    app.add_handler(CommandHandler("admin", admin))
    app.add_handler(CommandHandler("users", users))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CommandHandler("addproduct", add_product))
    app.add_handler(CommandHandler("products", products))
    app.add_handler(CommandHandler("setprice", set_price))
    app.add_handler(CommandHandler("approvedeposit", approve_deposit))
    app.add_handler(CommandHandler("rejectdeposit", reject_deposit))
    app.add_handler(CommandHandler("completeorder", complete_order))
    app.add_handler(CommandHandler("rejectorder", reject_order))
    app.add_handler(CommandHandler("credit", credit))
    app.add_handler(CommandHandler("debit", debit))
    app.add_handler(CommandHandler("broadcast", broadcast))
    app.add_handler(CommandHandler("grouppost", group_post))
    app.add_handler(CommandHandler("setgroup", set_group))
    app.add_handler(CommandHandler("setpayment", set_payment_info))
    app.add_handler(CommandHandler("commandlogs", command_logs))

    app.add_handler(CallbackQueryHandler(menu_callback))
    app.add_handler(MessageHandler(filters.PHOTO, payment_proof))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_router))

    logger.info("ISRAFILXSHOP bot is starting...")
    app.run_polling(allowed_updates=["message", "callback_query"])

if __name__ == "__main__":
    main()
