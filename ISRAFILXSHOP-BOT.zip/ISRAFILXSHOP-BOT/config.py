import os

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_IDS = {
    int(x.strip()) for x in os.getenv("ADMIN_IDS", "8312390543").split(",")
    if x.strip().isdigit()
}
DB_PATH = os.getenv("DB_PATH", "data/bot.sqlite3")
BOT_LANGUAGE = os.getenv("BOT_LANGUAGE", "both").lower()
SHOP_NAME = os.getenv("SHOP_NAME", "ISRAFILXSHOP")
SUPPORT_TELEGRAM = os.getenv("SUPPORT_TELEGRAM", "")
SUPPORT_WHATSAPP = os.getenv("SUPPORT_WHATSAPP", "")
TELEGRAM_CHANNEL = os.getenv("TELEGRAM_CHANNEL", "")
WHATSAPP_CHANNEL = os.getenv("WHATSAPP_CHANNEL", "")
PAYMENT_MODE = os.getenv("PAYMENT_MODE", "both").lower()  # manual, gateway, both
BKASH_NUMBER = os.getenv("BKASH_NUMBER", "")
NAGAD_NUMBER = os.getenv("NAGAD_NUMBER", "")
PAYMENT_INSTRUCTIONS = os.getenv("PAYMENT_INSTRUCTIONS", "Send payment and submit the transaction ID/screenshot.")
PUBLIC_ORDER_GROUP_ID = os.getenv("PUBLIC_ORDER_GROUP_ID", "")
# Generic gateway placeholder: configure a real provider adapter before enabling live payments.
GATEWAY_ENABLED = os.getenv("GATEWAY_ENABLED", "false").lower() == "true"
