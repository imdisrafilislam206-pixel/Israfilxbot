# ISRAFILXSHOP Telegram Shop Bot

Bilingual (Bangla/English UI starter) Telegram shop bot with:
- Automatic customer registration on `/start`
- Product categories and editable products
- Wallet, manual bKash/Nagad deposit requests, screenshot forwarding
- Admin approval/rejection of deposits
- Wallet-funded orders, admin completion/rejection and automatic refund on rejection
- Customer order history
- Admin statistics, user list, wallet credit/debit, broadcast, group post
- Activity/command log
- SQLite database

## Important limitations
1. The bot does **not** automatically deliver Free Fire items. Orders are queued for an admin/operator to fulfill. Only connect a legitimate, authorized service API if you have one.
2. Manual payments are supported. A real automatic payment gateway is **not live by default**. `payments/gateway.py` is a secure integration placeholder; implement the official provider API and signed webhook verification before enabling it.
3. The UI language selection is currently based on Telegram's language code (Bangla or English). Some admin responses are English. Extend translations as needed.
4. Add the bot to your order group as an administrator to allow group announcements. Use `/setgroup -100...` from the admin account.
5. Telegram bots cannot create Telegram user accounts. `/start` creates a customer profile in this shop's own database.

## 1. Create the bot
- Open `@BotFather` in Telegram.
- Run `/newbot`, follow the steps, and copy the token.
- Never publish the token or commit it to GitHub.

## 2. GitHub setup
- Create a private repository named `ISRAFILXSHOP-BOT`.
- Upload the project files.
- In repository Settings -> Secrets and variables -> Actions / your hosting provider's environment settings, add the environment variables from `.env.example`.
- Do not upload `.env`.

## 3. Run locally or on a VPS
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env and set BOT_TOKEN, ADMIN_IDS, payment numbers and links
python main.py
```
On Windows, activate with `.venv\\Scripts\\activate`.

## 4. Admin commands
Only Telegram user IDs in `ADMIN_IDS` can use these commands.

| Command | Purpose |
|---|---|
| `/admin` | Admin command guide |
| `/stats` | Users, orders and deposit totals |
| `/users` | Latest customer list |
| `/products` | Product list |
| `/addproduct category\|name\|price\|description` | Add product |
| `/setprice product_id price` | Change price |
| `/approvedeposit id` | Approve deposit and credit wallet |
| `/rejectdeposit id` | Reject pending deposit |
| `/completeorder id` | Complete order |
| `/rejectorder id` | Reject and refund order |
| `/credit user_id amount reason` | Add wallet credit |
| `/debit user_id amount reason` | Debit wallet |
| `/broadcast message` | Send message to all registered users |
| `/setgroup chat_id` | Configure order announcement group |
| `/grouppost message` | Post in configured group |
| `/setpayment instructions` | Save payment instructions |
| `/commandlogs` | Recent activity |

## 5. Deposit workflow
Customer taps Deposit, sends amount, chooses `bkash` or `nagad`, submits transaction ID, then sends screenshot. Admin receives a request and screenshot. Approve with `/approvedeposit ID`. Do not approve until you independently verify the transaction in your merchant/mobile-financial-service account.

## 6. Product workflow
Customers choose a category and product, submit UID and server/region. The bot debits wallet and sends the order to the admin. Fulfill it manually, then use `/completeorder ID`. If unable to fulfill, use `/rejectorder ID` to refund.

## 7. Payment gateway
Keep `GATEWAY_ENABLED=false` until an official gateway provider has been selected and integrated. Never trust client-side redirects or screenshots as gateway confirmation. Verify signed webhooks server-to-server and make approval idempotent.

## 8. Production checklist
- Use a private GitHub repository.
- Set a strong BotFather token as a secret/environment variable.
- Restrict `ADMIN_IDS` to trusted numeric Telegram IDs.
- Back up the SQLite database regularly; for multi-instance hosting use PostgreSQL.
- Use HTTPS and provider-signed webhooks for gateway integration.
- Add terms, refund policy, privacy notice, pricing and support contacts.
- Test deposits, refunds, duplicate updates, bot restarts and backup restore before accepting real money.
