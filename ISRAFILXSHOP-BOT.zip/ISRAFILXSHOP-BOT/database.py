import os, sqlite3
from contextlib import contextmanager
from config import DB_PATH

def _connect():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

@contextmanager
def db():
    conn = _connect()
    try:
        yield conn
        conn.commit()
    except:
        conn.rollback()
        raise
    finally:
        conn.close()

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
            user_id INTEGER PRIMARY KEY, username TEXT, full_name TEXT,
            balance REAL NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS products(
            id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL,
            name TEXT NOT NULL, description TEXT DEFAULT '', price REAL NOT NULL,
            active INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS orders(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            product_id INTEGER, product_name TEXT NOT NULL, price REAL NOT NULL,
            game_uid TEXT DEFAULT '', server TEXT DEFAULT '', status TEXT DEFAULT 'PENDING',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP, completed_at TEXT,
            FOREIGN KEY(user_id) REFERENCES users(user_id)
        );
        CREATE TABLE IF NOT EXISTS deposits(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            amount REAL NOT NULL, method TEXT NOT NULL, trx_id TEXT DEFAULT '',
            proof_file_id TEXT DEFAULT '', status TEXT DEFAULT 'PENDING',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP, reviewed_at TEXT,
            FOREIGN KEY(user_id) REFERENCES users(user_id)
        );
        CREATE TABLE IF NOT EXISTS ledger(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            amount REAL NOT NULL, kind TEXT NOT NULL, reference TEXT DEFAULT '',
            note TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS command_logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, username TEXT,
            command TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS sessions(
            user_id INTEGER PRIMARY KEY, state TEXT NOT NULL, data TEXT DEFAULT ''
        );
        """)
        defaults = {
            "payment_info": "bKash/Nagad payment details will be configured by admin.",
            "public_group_id": "",
            "telegram_channel": "",
            "whatsapp_channel": "",
            "support_telegram": "",
            "support_whatsapp": ""
        }
        for k, v in defaults.items():
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k,v))
        count = c.execute("SELECT COUNT(*) n FROM products").fetchone()["n"]
        if count == 0:
            starter = [
                ("Diamond Top Up","25 Diamonds","UID top-up service",25),
                ("Diamond Top Up","50 Diamonds","UID top-up service",45),
                ("Membership","Weekly Membership","7-day membership",150),
                ("Membership","Monthly Membership","30-day membership",650),
                ("Pass","Level Up Pass","Level-up pass service",160),
                ("Auto Like","200 Likes","Like service",25),
                ("Guild","Guild Glory","Manual processing",50),
                ("Other Items","Universal Voucher","Voucher service",50),
            ]
            c.executemany("INSERT INTO products(category,name,description,price) VALUES(?,?,?,?)", starter)

def log_command(user, command):
    with db() as c:
        c.execute("INSERT INTO command_logs(user_id,username,command) VALUES(?,?,?)",
                  (user.id, user.username or "", command))

def ensure_user(user):
    with db() as c:
        c.execute("""INSERT INTO users(user_id,username,full_name) VALUES(?,?,?)
        ON CONFLICT(user_id) DO UPDATE SET username=excluded.username, full_name=excluded.full_name""",
        (user.id, user.username or "", user.full_name or ""))

def get_setting(key, default=""):
    with db() as c:
        row = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

def set_setting(key, value):
    with db() as c:
        c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                  (key, str(value)))

def list_products():
    with db() as c:
        return c.execute("SELECT * FROM products WHERE active=1 ORDER BY category,id").fetchall()

def get_product(pid):
    with db() as c:
        return c.execute("SELECT * FROM products WHERE id=? AND active=1", (pid,)).fetchone()

def user_balance(uid):
    with db() as c:
        r = c.execute("SELECT balance FROM users WHERE user_id=?", (uid,)).fetchone()
        return float(r["balance"]) if r else 0.0

def add_ledger(uid, amount, kind, reference="", note=""):
    with db() as c:
        c.execute("UPDATE users SET balance=balance+? WHERE user_id=?", (amount,uid))
        c.execute("INSERT INTO ledger(user_id,amount,kind,reference,note) VALUES(?,?,?,?,?)",
                  (uid,amount,kind,reference,note))

def create_deposit(uid, amount, method, trx="", proof=""):
    with db() as c:
        cur = c.execute("INSERT INTO deposits(user_id,amount,method,trx_id,proof_file_id) VALUES(?,?,?,?,?)",
                        (uid,amount,method,trx,proof))
        return cur.lastrowid

def create_order(uid, product, game_uid, server):
    with db() as c:
        # Atomic wallet debit and order insert; prevents spending a negative balance.
        row = c.execute("SELECT balance FROM users WHERE user_id=?", (uid,)).fetchone()
        if not row or float(row["balance"]) < float(product["price"]):
            return None
        c.execute("UPDATE users SET balance=balance-? WHERE user_id=?", (product["price"],uid))
        cur = c.execute("""INSERT INTO orders(user_id,product_id,product_name,price,game_uid,server)
                           VALUES(?,?,?,?,?,?)""",
                        (uid,product["id"],product["name"],product["price"],game_uid,server))
        c.execute("INSERT INTO ledger(user_id,amount,kind,reference,note) VALUES(?,?,?,?,?)",
                  (uid,-float(product["price"]),"ORDER",str(cur.lastrowid),product["name"]))
        return cur.lastrowid
