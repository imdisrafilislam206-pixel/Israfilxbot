from telegram import Update
from telegram.ext import ContextTypes
from config import SUPPORT_TELEGRAM, SUPPORT_WHATSAPP
from database import log_command

async def support(update: Update, context: ContextTypes.DEFAULT_TYPE, from_callback=False):
    user = update.effective_user
    if not from_callback: log_command(user, "/support")
    text = "Customer support / কাস্টমার সাপোর্ট\n"
    text += f"Telegram: {SUPPORT_TELEGRAM or 'Not configured'}\n"
    text += f"WhatsApp: {SUPPORT_WHATSAPP or 'Not configured'}"
    if from_callback: await update.callback_query.message.reply_text(text)
    else: await update.message.reply_text(text)
