from telegram import Update
from telegram.ext import ContextTypes
from config import ADMIN_IDS, BKASH_NUMBER, NAGAD_NUMBER
from database import db, add_ledger, set_setting, get_setting, log_command

def is_admin(uid): return uid in ADMIN_IDS

async def guard(update):
    if not is_admin(update.effective_user.id):
        target = update.effective_message
        await target.reply_text("⛔ Admin access only.")
        return False
    return True

async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard(update): return
    await update.message.reply_text(
        "ADMIN PANEL\n"
        "/stats — statistics\n/users — customer list\n/products — products\n"
        "/addproduct category|name|price|description\n"
        "/setprice product_id price\n/approvedeposit deposit_id\n/rejectdeposit deposit_id\n"
        "/completeorder order_id\n/rejectorder order_id\n"
        "/credit user_id amount reason\n/debit user_id amount reason\n"
        "/broadcast message\n/grouppost message\n/setgroup chat_id\n"
        "/setpayment payment instructions\n/commandlogs"
    )

async def stats(update, context):
    if not await guard(update): return
    with db() as c:
        u=c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        o=c.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"]
        d=c.execute("SELECT COUNT(*) n FROM deposits WHERE status='APPROVED'").fetchone()["n"]
        pending=c.execute("SELECT COUNT(*) n FROM orders WHERE status='PENDING'").fetchone()["n"]
        total=c.execute("SELECT COALESCE(SUM(amount),0) s FROM deposits WHERE status='APPROVED'").fetchone()["s"]
    await update.message.reply_text(f"Users: {u}\nOrders: {o}\nPending orders: {pending}\nApproved deposits: {d}\nDeposit total: ৳{total:.2f}")

async def users(update, context):
    if not await guard(update): return
    with db() as c:
        rows=c.execute("SELECT user_id,username,full_name,balance FROM users ORDER BY created_at DESC LIMIT 100").fetchall()
    text="Customers (latest 100):\n"+"\n".join(f"{r['user_id']} | @{r['username']} | {r['full_name']} | ৳{r['balance']:.2f}" for r in rows)
    await update.message.reply_text(text[:4000] or "No users.")

async def products(update, context):
    if not await guard(update): return
    with db() as c: rows=c.execute("SELECT id,category,name,price,active FROM products ORDER BY id").fetchall()
    await update.message.reply_text("Products:\n"+"\n".join(f"#{r['id']} [{r['category']}] {r['name']} — ৳{r['price']:.2f} active={r['active']}" for r in rows)[:4000])

async def add_product(update, context):
    if not await guard(update): return
    raw=" ".join(context.args)
    parts=[x.strip() for x in raw.split("|",3)]
    if len(parts)<3:
        await update.message.reply_text("Format: /addproduct category|name|price|description"); return
    try: price=float(parts[2]); assert price>=0
    except: await update.message.reply_text("Invalid price."); return
    desc=parts[3] if len(parts)>3 else ""
    with db() as c: cur=c.execute("INSERT INTO products(category,name,price,description) VALUES(?,?,?,?)",(parts[0],parts[1],price,desc))
    await update.message.reply_text(f"Product added. ID: {cur.lastrowid}")

async def set_price(update, context):
    if not await guard(update): return
    try: pid=int(context.args[0]); price=float(context.args[1]); assert price>=0
    except: await update.message.reply_text("Format: /setprice product_id price"); return
    with db() as c: c.execute("UPDATE products SET price=? WHERE id=?",(price,pid))
    await update.message.reply_text("Price updated.")

async def approve_deposit(update, context):
    if not await guard(update): return
    try: did=int(context.args[0])
    except: await update.message.reply_text("Format: /approvedeposit deposit_id"); return
    with db() as c:
        row=c.execute("SELECT * FROM deposits WHERE id=? AND status='PENDING'",(did,)).fetchone()
        if not row: await update.message.reply_text("Pending deposit not found."); return
        c.execute("UPDATE deposits SET status='APPROVED',reviewed_at=CURRENT_TIMESTAMP WHERE id=?",(did,))
        c.execute("UPDATE users SET balance=balance+? WHERE user_id=?",(row["amount"],row["user_id"]))
        c.execute("INSERT INTO ledger(user_id,amount,kind,reference,note) VALUES(?,?,?,?,?)",(row["user_id"],row["amount"],"DEPOSIT",str(did),row["method"]))
    await context.bot.send_message(row["user_id"],f"Deposit #{did} approved. ৳{row['amount']:.2f} added to your wallet.")
    await update.message.reply_text("Deposit approved and wallet credited.")

async def reject_deposit(update, context):
    if not await guard(update): return
    try: did=int(context.args[0])
    except: await update.message.reply_text("Format: /rejectdeposit deposit_id"); return
    with db() as c:
        cur=c.execute("UPDATE deposits SET status='REJECTED',reviewed_at=CURRENT_TIMESTAMP WHERE id=? AND status='PENDING'",(did,))
        row=c.execute("SELECT user_id FROM deposits WHERE id=?",(did,)).fetchone()
    if cur.rowcount and row: await context.bot.send_message(row["user_id"],f"Deposit #{did} was rejected. Contact support if you need help.")
    await update.message.reply_text("Deposit rejected (if it was pending).")

async def complete_order(update, context):
    if not await guard(update): return
    try: oid=int(context.args[0])
    except: await update.message.reply_text("Format: /completeorder order_id"); return
    with db() as c:
        row=c.execute("SELECT * FROM orders WHERE id=? AND status='PENDING'",(oid,)).fetchone()
        if not row: await update.message.reply_text("Pending order not found."); return
        c.execute("UPDATE orders SET status='COMPLETED',completed_at=CURRENT_TIMESTAMP WHERE id=?",(oid,))
        group=get_setting("public_group_id","")
    await context.bot.send_message(row["user_id"],f"Order #{oid} ({row['product_name']}) is completed.")
    if group:
        try: await context.bot.send_message(int(group),f"✅ Order #{oid} completed — {row['product_name']}")
        except Exception: pass
    await update.message.reply_text("Order marked completed.")

async def reject_order(update, context):
    if not await guard(update): return
    try: oid=int(context.args[0])
    except: await update.message.reply_text("Format: /rejectorder order_id"); return
    with db() as c:
        row=c.execute("SELECT * FROM orders WHERE id=? AND status='PENDING'",(oid,)).fetchone()
        if not row: await update.message.reply_text("Pending order not found."); return
        c.execute("UPDATE orders SET status='REJECTED' WHERE id=?",(oid,))
        c.execute("UPDATE users SET balance=balance+? WHERE user_id=?",(row["price"],row["user_id"]))
        c.execute("INSERT INTO ledger(user_id,amount,kind,reference,note) VALUES(?,?,?,?,?)",(row["user_id"],row["price"],"REFUND",str(oid),"Rejected order refund"))
    await context.bot.send_message(row["user_id"],f"Order #{oid} rejected. ৳{row['price']:.2f} refunded.")
    await update.message.reply_text("Order rejected and refunded.")

async def credit(update, context):
    if not await guard(update): return
    try: uid=int(context.args[0]); amount=float(context.args[1]); assert amount>0
    except: await update.message.reply_text("Format: /credit user_id amount reason"); return
    reason=" ".join(context.args[2:]) or "Admin credit"
    add_ledger(uid,amount,"ADMIN_CREDIT","",reason)
    await update.message.reply_text("Wallet credited.")

async def debit(update, context):
    if not await guard(update): return
    try: uid=int(context.args[0]); amount=float(context.args[1]); assert amount>0
    except: await update.message.reply_text("Format: /debit user_id amount reason"); return
    reason=" ".join(context.args[2:]) or "Admin debit"
    with db() as c:
        row=c.execute("SELECT balance FROM users WHERE user_id=?",(uid,)).fetchone()
        if not row or row["balance"]<amount: await update.message.reply_text("User not found or insufficient balance."); return
        c.execute("UPDATE users SET balance=balance-? WHERE user_id=?",(amount,uid))
        c.execute("INSERT INTO ledger(user_id,amount,kind,note) VALUES(?,?,?,?)",(uid,-amount,"ADMIN_DEBIT",reason))
    await update.message.reply_text("Wallet debited.")

async def broadcast(update, context):
    if not await guard(update): return
    text=" ".join(context.args)
    if not text: await update.message.reply_text("Format: /broadcast your message"); return
    with db() as c: ids=[r["user_id"] for r in c.execute("SELECT user_id FROM users").fetchall()]
    sent=0
    for uid in ids:
        try: await context.bot.send_message(uid,text); sent+=1
        except Exception: pass
    await update.message.reply_text(f"Broadcast sent to {sent}/{len(ids)} users.")

async def group_post(update, context):
    if not await guard(update): return
    text=" ".join(context.args)
    group=get_setting("public_group_id","")
    if not group or not text: await update.message.reply_text("Set group first: /setgroup chat_id; then /grouppost message"); return
    try: await context.bot.send_message(int(group),text); await update.message.reply_text("Posted.")
    except Exception as e: await update.message.reply_text(f"Could not post: {e}")

async def set_group(update, context):
    if not await guard(update): return
    if not context.args: await update.message.reply_text("Format: /setgroup chat_id"); return
    set_setting("public_group_id",context.args[0]); await update.message.reply_text("Group configured.")

async def set_payment_info(update, context):
    if not await guard(update): return
    text=" ".join(context.args)
    if not text: await update.message.reply_text("Format: /setpayment payment instructions"); return
    set_setting("payment_info",text); await update.message.reply_text("Payment instructions saved.")

async def command_logs(update, context):
    if not await guard(update): return
    with db() as c: rows=c.execute("SELECT user_id,username,command,created_at FROM command_logs ORDER BY id DESC LIMIT 40").fetchall()
    await update.message.reply_text("Recent activity:\n"+"\n".join(f"{r['created_at']} | {r['user_id']} @{r['username']} | {r['command']}" for r in rows)[:4000])

async def notify_admins_new_order(context, oid, user, product, uid, server):
    for aid in ADMIN_IDS:
        try: await context.bot.send_message(aid,f"🛒 New order #{oid}\nCustomer: {user.full_name} ({user.id})\nProduct: {product['name']}\nUID: {uid}\nServer: {server}\nAmount: ৳{product['price']:.2f}\nUse /completeorder {oid} or /rejectorder {oid}")
        except Exception: pass

async def notify_admins_deposit(context, did, user, amount, method, trx):
    for aid in ADMIN_IDS:
        try: await context.bot.send_message(aid,f"💳 Deposit request #{did}\nCustomer: {user.full_name} ({user.id})\nAmount: ৳{amount:.2f}\nMethod: {method}\nTRX: {trx or 'not supplied'}\nApprove: /approvedeposit {did}\nReject: /rejectdeposit {did}")
        except Exception: pass

async def notify_admins_proof(context, did, user, file_id):
    for aid in ADMIN_IDS:
        try:
            await context.bot.send_photo(aid,file_id,caption=f"Payment proof for deposit #{did}\nUser: {user.id}\nApprove: /approvedeposit {did}")
        except Exception: pass
