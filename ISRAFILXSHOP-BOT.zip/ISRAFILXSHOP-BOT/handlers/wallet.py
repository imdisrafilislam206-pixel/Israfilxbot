from telegram import Update
from telegram.ext import ContextTypes
from database import user_balance, create_deposit, ensure_user, log_command
from config import ADMIN_IDS, BKASH_NUMBER, NAGAD_NUMBER, PAYMENT_MODE, GATEWAY_ENABLED

async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ensure_user(update.effective_user); log_command(update.effective_user, "/balance")
    await update.message.reply_text(f"Your balance: ৳{user_balance(update.effective_user.id):.2f}")

async def deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ensure_user(update.effective_user); log_command(update.effective_user, "/deposit")
    await update.message.reply_text(
        f"Deposit methods:\n bKash: {BKASH_NUMBER or 'Not configured'}\n"
        f"Nagad: {NAGAD_NUMBER or 'Not configured'}\n\n"
        "Use the Deposit button in /start and follow the steps. Admin approval is required."
    )

async def payment_proof(update: Update, context: ContextTypes.DEFAULT_TYPE):
    photo = update.message.photo[-1]
    uid = update.effective_user.id
    # Attach the latest proof to the most recent pending deposit by this user.
    from database import db
    with db() as c:
        row = c.execute("SELECT id FROM deposits WHERE user_id=? AND status='PENDING' ORDER BY id DESC LIMIT 1",(uid,)).fetchone()
        if not row:
            await update.message.reply_text("No pending deposit found. Start with Deposit first.")
            return
        c.execute("UPDATE deposits SET proof_file_id=? WHERE id=?", (photo.file_id,row["id"]))
        dep_id = row["id"]
    await update.message.reply_text(f"Screenshot attached to deposit #{dep_id}.")
    from handlers.admin import notify_admins_proof
    await notify_admins_proof(context, dep_id, update.effective_user, photo.file_id)
