import json
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes
from config import SHOP_NAME, TELEGRAM_CHANNEL, WHATSAPP_CHANNEL, SUPPORT_TELEGRAM, SUPPORT_WHATSAPP
from database import ensure_user, log_command, list_products, get_product, create_order, user_balance, db

def lang(update):
    return "bn" if (update.effective_user.language_code or "").startswith("bn") else "en"

def msg(bn, en, l):
    return bn if l == "bn" else en

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    ensure_user(u); log_command(u, "/start")
    l = lang(update)
    kb = [
        [InlineKeyboardButton(msg("🛍️ পণ্য কিনুন","🛍️ Shop products",l), callback_data="shop")],
        [InlineKeyboardButton(msg("💰 ব্যালেন্স","💰 Balance",l), callback_data="balance"),
         InlineKeyboardButton(msg("➕ টাকা জমা","➕ Deposit",l), callback_data="deposit")],
        [InlineKeyboardButton(msg("📦 আমার অর্ডার","📦 My orders",l), callback_data="orders"),
         InlineKeyboardButton(msg("🆘 সাপোর্ট","🆘 Support",l), callback_data="support")],
        [InlineKeyboardButton("📢 Telegram", url=TELEGRAM_CHANNEL)] if TELEGRAM_CHANNEL.startswith("https://") else [],
        [InlineKeyboardButton("🟢 WhatsApp", url=WHATSAPP_CHANNEL)] if WHATSAPP_CHANNEL.startswith("https://") else [],
    ]
    kb = [x for x in kb if x]
    await update.message.reply_text(
        f"Welcome to {SHOP_NAME}!\n\n"
        + msg("আপনার অ্যাকাউন্ট তৈরি/আপডেট হয়েছে। নিচের মেনু ব্যবহার করুন।",
              "Your account is ready. Choose an option below.",l),
        reply_markup=InlineKeyboardMarkup(kb)
    )

async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    uid = q.from_user.id
    ensure_user(q.from_user)
    l = "bn" if (q.from_user.language_code or "").startswith("bn") else "en"
    if q.data == "shop":
        rows = {}
        for p in list_products():
            rows.setdefault(p["category"], []).append(p)
        kb = []
        for category, products in rows.items():
            kb.append([InlineKeyboardButton(f"📂 {category}", callback_data="cat:"+category)])
        await q.message.reply_text("Choose category / ক্যাটাগরি নির্বাচন করুন:", reply_markup=InlineKeyboardMarkup(kb))
    elif q.data.startswith("cat:"):
        cat = q.data[4:]
        kb = [[InlineKeyboardButton(f"{p['name']} — ৳{p['price']:.2f}", callback_data=f"buy:{p['id']}")]
              for p in list_products() if p["category"] == cat]
        await q.message.reply_text(cat, reply_markup=InlineKeyboardMarkup(kb))
    elif q.data.startswith("buy:"):
        pid = int(q.data.split(":")[1])
        p = get_product(pid)
        if not p:
            await q.message.reply_text("Product unavailable.")
            return
        context.user_data["pending_product"] = pid
        context.user_data["awaiting_uid"] = True
        await q.message.reply_text(
            f"Selected: {p['name']}\nPrice: ৳{p['price']:.2f}\n"
            "Send your Free Fire UID now. For products that do not need UID, send -"
        )
    elif q.data == "balance":
        await q.message.reply_text(f"Wallet balance: ৳{user_balance(uid):.2f}")
    elif q.data == "deposit":
        context.user_data["deposit_step"] = "amount"
        await q.message.reply_text("Send deposit amount in BDT (e.g. 200):")
    elif q.data == "orders":
        from handlers.orders import my_orders
        await my_orders(update, context, from_callback=True)
    elif q.data == "support":
        from handlers.support import support
        await support(update, context, from_callback=True)

async def text_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    ensure_user(u); log_command(u, update.message.text[:80])
    text = update.message.text.strip()
    if context.user_data.get("awaiting_uid"):
        pid = context.user_data.pop("pending_product", None)
        context.user_data["awaiting_uid"] = False
        if not pid:
            await update.message.reply_text("Session expired. Please choose the product again.")
            return
        p = get_product(pid)
        if not p: 
            await update.message.reply_text("Product unavailable."); return
        context.user_data["pending_uid"] = text
        context.user_data["pending_product_confirm"] = pid
        context.user_data["awaiting_server"] = True
        await update.message.reply_text("Send server/region (or - if not required):")
        return
    if context.user_data.get("awaiting_server"):
        context.user_data["awaiting_server"] = False
        pid = context.user_data.pop("pending_product_confirm", None)
        game_uid = context.user_data.pop("pending_uid", "")
        p = get_product(pid) if pid else None
        if not p:
            await update.message.reply_text("Session expired."); return
        order_id = create_order(u.id, p, game_uid, text)
        if order_id is None:
            await update.message.reply_text("Insufficient wallet balance. Deposit first.")
            return
        await update.message.reply_text(f"Order #{order_id} created. Status: PENDING.")
        from handlers.admin import notify_admins_new_order
        await notify_admins_new_order(context, order_id, u, p, game_uid, text)
        return
    if context.user_data.get("deposit_step") == "amount":
        try:
            amount = float(text)
            if amount <= 0 or amount > 100000:
                raise ValueError()
        except ValueError:
            await update.message.reply_text("Enter a valid amount greater than 0.")
            return
        context.user_data["deposit_amount"] = amount
        context.user_data["deposit_step"] = "method"
        await update.message.reply_text("Choose method: type bkash or nagad")
        return
    if context.user_data.get("deposit_step") == "method":
        method = text.lower()
        if method not in ("bkash","nagad"):
            await update.message.reply_text("Type bkash or nagad.")
            return
        context.user_data["deposit_method"] = method
        context.user_data["deposit_step"] = "trx"
        await update.message.reply_text("Send transaction ID (or type SKIP, then send screenshot):")
        return
    if context.user_data.get("deposit_step") == "trx":
        from database import create_deposit, get_setting
        amount = context.user_data.pop("deposit_amount")
        method = context.user_data.pop("deposit_method")
        context.user_data.pop("deposit_step", None)
        trx = "" if text.upper() == "SKIP" else text
        dep_id = create_deposit(u.id, amount, method, trx)
        await update.message.reply_text(f"Deposit request #{dep_id} submitted. Send payment screenshot in this chat if available.")
        from handlers.admin import notify_admins_deposit
        await notify_admins_deposit(context, dep_id, u, amount, method, trx)
        return
    await update.message.reply_text("Use /start to open the menu. /help is coming soon.")
