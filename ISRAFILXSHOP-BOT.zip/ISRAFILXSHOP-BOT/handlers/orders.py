from telegram import Update
from telegram.ext import ContextTypes
from database import db, ensure_user, log_command

async def my_orders(update: Update, context: ContextTypes.DEFAULT_TYPE, from_callback=False):
    user = update.effective_user
    ensure_user(user)
    if not from_callback: log_command(user, "/myorders")
    with db() as c:
        rows = c.execute("SELECT id,product_name,price,status,created_at FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 15",(user.id,)).fetchall()
    if not rows:
        text = "You have no orders yet."
    else:
        text = "Your recent orders:\n" + "\n".join(
            f"#{r['id']} {r['product_name']} | ৳{r['price']:.2f} | {r['status']} | {r['created_at']}" for r in rows)
    if from_callback: await update.callback_query.message.reply_text(text)
    else: await update.message.reply_text(text)
